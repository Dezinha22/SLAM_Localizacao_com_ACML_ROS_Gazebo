#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Visualização
Mapa: Gmapping
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import numpy as np
import yaml
from PIL import Image
import rosbag
import os
from datetime import datetime

MAP_YAML = "/ws/src/husky_part3_20260629/maps/mapa_gmapping.yaml"
BAG_PATH = "/ws/2026-06-16-00-36-58-001.bag"
OUTPUT_DIR = "/ws/src/husky_part3_20260629/figures/gmapping"
DPI = 300

def load_map(yaml_path):
    with open(yaml_path, 'r') as f:
        map_metadata = yaml.safe_load(f)
    
    map_img_path = os.path.join(os.path.dirname(yaml_path), map_metadata['image'])
    map_img = np.array(Image.open(map_img_path))
    
    if len(map_img.shape) == 3:
        map_img = map_img[:, :, 0]
    
    resolution = map_metadata['resolution']
    origin = map_metadata['origin']
    
    return map_img, resolution, origin

def get_trajectory(bag_path):
    bag = rosbag.Bag(bag_path)
    x, y = [], []
    
    for topic, msg, t in bag.read_messages(topics=['/gazebo_ground_truth/odom']):
        x.append(msg.pose.pose.position.x)
        y.append(msg.pose.pose.position.y)
    
    bag.close()
    return np.array(x), np.array(y)

def plot_map_with_trajectory(map_img, resolution, origin, x, y, output_path):
    fig, ax = plt.subplots(figsize=(14, 12), dpi=DPI)
    
    height, width = map_img.shape
    extent = [
        origin[0],
        origin[0] + width * resolution,
        origin[1],
        origin[1] + height * resolution
    ]
    
    map_img = np.flipud(map_img)
    
    ax.imshow(map_img, cmap='gray', extent=extent, origin='lower')
    
    ax.plot(x, y, color='#e74c3c', linewidth=2.0, label='Trajetória do Robô (Ground Truth)')
    ax.plot(x[0], y[0], 'go', markersize=8, label='Início')
    ax.plot(x[-1], y[-1], 'g^', markersize=8, label='Fim')
    
    ax.set_xlabel('Posição X (m)', fontsize=13)
    ax.set_ylabel('Posição Y (m)', fontsize=13)
    ax.set_title('Mapa de Ocupação + Trajetória do Robô\nGmapping + Ground Truth', fontsize=15, fontweight='bold')
    ax.legend(fontsize=11, loc='upper right')
    ax.grid(True, alpha=0.3)
    ax.set_aspect('equal')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=DPI, bbox_inches='tight')
    plt.close()
    print(f"Figura salva em: {output_path}")

def main():
    print("=== Gerando visualização profissional - Gmapping ===\n")
    
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = os.path.join(OUTPUT_DIR, f"mapa_gmapping_trajetoria_{timestamp}.png")
    
    print("Carregando mapa...")
    map_img, resolution, origin = load_map(MAP_YAML)
    
    print("Extraindo trajetória...")
    x, y = get_trajectory(BAG_PATH)
    
    print("Gerando figura de alta qualidade...")
    plot_map_with_trajectory(map_img, resolution, origin, x, y, output_path)
    
    print("\nConcluído com sucesso!")

if __name__ == "__main__":
    main()
