#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Métricas de Estabilidade - Gmapping
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import rosbag
import numpy as np
from datetime import datetime
import os
import tf.transformations as tf_trans

BAG_PATH = "/ws/src/husky_part3_20260629/bags/amcl_gmapping_comparison.bag"
OUTPUT_BASE = "/ws/src/husky_part3_20260629/analysis/gmapping"
TIME_TOLERANCE = 0.5

def get_yaw(q):
    return tf_trans.euler_from_quaternion([q.x, q.y, q.z, q.w])[2]

def main():
    print("=== Análise com Métricas de Estabilidade - Gmapping ===\n")
    
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = os.path.join(OUTPUT_BASE, ts)
    os.makedirs(out_dir, exist_ok=True)

    bag = rosbag.Bag(BAG_PATH)
    amcl_list, gt_list = [], []

    for topic, msg, _ in bag.read_messages(topics=['/amcl_pose', '/gazebo_ground_truth/odom']):
        if topic == '/amcl_pose':
            amcl_list.append({
                't': msg.header.stamp.to_sec(),
                'x': msg.pose.pose.position.x,
                'y': msg.pose.pose.position.y,
                'yaw': get_yaw(msg.pose.pose.orientation)
            })
        else:
            gt_list.append({
                't': msg.header.stamp.to_sec(),
                'x': msg.pose.pose.position.x,
                'y': msg.pose.pose.position.y,
                'yaw': get_yaw(msg.pose.pose.orientation)
            })
    bag.close()

    print(f"AMCL: {len(amcl_list)} | GT: {len(gt_list)}")

    # Sincronização
    synced = []
    for a in amcl_list:
        g = min(gt_list, key=lambda x: abs(x['t'] - a['t']))
        if abs(g['t'] - a['t']) <= TIME_TOLERANCE:
            synced.append({
                't': a['t'],
                'amcl_x': a['x'], 'amcl_y': a['y'], 'amcl_yaw': a['yaw'],
                'gt_x': g['x'], 'gt_y': g['y'], 'gt_yaw': g['yaw']
            })

    if len(synced) < 10:
        print("ERRO: Poucos dados sincronizados.")
        return

    print(f"Sincronizados: {len(synced)}")

    # Cálculo dos erros
    amcl_x = np.array([s['amcl_x'] for s in synced])
    amcl_y = np.array([s['amcl_y'] for s in synced])
    gt_x = np.array([s['gt_x'] for s in synced])
    gt_y = np.array([s['gt_y'] for s in synced])

    pos_err = np.sqrt((amcl_x - gt_x)**2 + (amcl_y - gt_y)**2)
    yaw_err = np.abs(np.array([s['amcl_yaw'] for s in synced]) - np.array([s['gt_yaw'] for s in synced]))
    yaw_err = np.minimum(yaw_err, 2*np.pi - yaw_err)

    # Métricas de erro
    metrics = {
        'n': len(synced),
        'rmse_pos': float(np.sqrt(np.mean(pos_err**2))),
        'mean_pos': float(np.mean(pos_err)),
        'max_pos': float(np.max(pos_err)),
        'std_pos_error': float(np.std(pos_err)),
        'final_pos': float(pos_err[-1]),
        'rmse_yaw': float(np.sqrt(np.mean(yaw_err**2))),
        'mean_yaw': float(np.mean(yaw_err)),
        'max_yaw': float(np.max(yaw_err)),
    }

    # Métricas de estabilidade
    dx = np.diff(amcl_x)
    dy = np.diff(amcl_y)
    jumps = np.sqrt(dx**2 + dy**2)

    metrics.update({
        'max_jump': float(np.max(jumps)),
        'mean_jump': float(np.mean(jumps)),
        'std_jump': float(np.std(jumps)),
        'var_amcl_x': float(np.var(amcl_x)),
        'var_amcl_y': float(np.var(amcl_y)),
    })

    # Gráficos
    t = np.array([s['t'] for s in synced]) - synced[0]['t']

    # Trajetória
    plt.figure(figsize=(13, 11))
    plt.plot(gt_x, gt_y, 'g-', linewidth=2.5, label='Ground Truth')
    plt.plot(amcl_x, amcl_y, 'r--', linewidth=2.0, label='AMCL')
    plt.plot(gt_x[0], gt_y[0], 'go', markersize=9, label='Início')
    plt.plot(gt_x[-1], gt_y[-1], 'g^', markersize=9, label='Fim GT')
    plt.xlabel('Posição X (m)', fontsize=12)
    plt.ylabel('Posição Y (m)', fontsize=12)
    plt.title('Comparação de Trajetória - AMCL vs Ground Truth\n(Mapa: Gmapping)', fontsize=14, fontweight='bold')
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.axis('equal')
    plt.tight_layout()
    plt.savefig(f"{out_dir}/trajectory_comparison.png", dpi=220, bbox_inches='tight')
    plt.close()

    # Erro de Posição
    plt.figure(figsize=(13, 7))
    plt.plot(t, pos_err, color='#e74c3c', linewidth=1.6)
    plt.axhline(y=metrics['rmse_pos'], color='blue', linestyle='--', linewidth=1.8,
                label=f'RMSE = {metrics["rmse_pos"]:.3f} m')
    plt.xlabel('Tempo (s)', fontsize=12)
    plt.ylabel('Erro de Posição (m)', fontsize=12)
    plt.title('Erro de Posição ao Longo do Tempo', fontsize=14, fontweight='bold')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(f"{out_dir}/position_error.png", dpi=220, bbox_inches='tight')
    plt.close()

    # Relatório
    report_path = os.path.join(out_dir, "relatorio_completo.txt")
    with open(report_path, "w") as f:
        f.write("="*80 + "\n")
        f.write("RELATÓRIO DE ANÁLISE - AMCL + Gmapping\n")
        f.write(f"Data: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n")
        f.write("="*80 + "\n\n")

        f.write("1. MÉTRICAS DE ERRO\n")
        f.write("-"*50 + "\n")
        f.write(f"RMSE Posição:             {metrics['rmse_pos']:.4f} m\n")
        f.write(f"Erro Médio Posição:       {metrics['mean_pos']:.4f} m\n")
        f.write(f"Erro Máximo Posição:      {metrics['max_pos']:.4f} m\n")
        f.write(f"Desvio Padrão do Erro:    {metrics['std_pos_error']:.4f} m\n")
        f.write(f"Erro Final Posição:       {metrics['final_pos']:.4f} m\n")
        f.write(f"RMSE Yaw:                 {metrics['rmse_yaw']:.4f} rad\n\n")

        f.write("2. MÉTRICAS DE ESTABILIDADE\n")
        f.write("-"*50 + "\n")
        f.write(f"Máximo Salto entre Poses: {metrics['max_jump']:.4f} m\n")
        f.write(f"Média dos Saltos:         {metrics['mean_jump']:.4f} m\n")
        f.write(f"Variância Posição X:      {metrics['var_amcl_x']:.6f} m²\n")
        f.write(f"Variância Posição Y:      {metrics['var_amcl_y']:.6f} m²\n")

    print(f"\nAnálise concluída!")
    print(f"Resultados salvos em: {out_dir}")

if __name__ == "__main__":
    main()
